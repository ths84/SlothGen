from setuptools import setup, find_packages

setup(
    name='SlothGen',
    version='0.1',
    author='ths84',
    author_email='t.shmdt@gmail.com',
    packages=find_packages(),
)